import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RecordatoriosRoutingModule } from './recordatorios-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RecordatoriosRoutingModule
  ]
})
export class RecordatoriosModule { }
