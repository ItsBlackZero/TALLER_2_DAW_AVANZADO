import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HistorialMedicoRoutingModule } from './historial-medico-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HistorialMedicoRoutingModule
  ]
})
export class HistorialMedicoModule { }
