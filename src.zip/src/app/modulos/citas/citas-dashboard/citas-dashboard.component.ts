import { Component } from '@angular/core';

@Component({
  selector: 'app-citas-dashboard',
  templateUrl: './citas-dashboard.component.html',
  styleUrl: './citas-dashboard.component.css'
})
export class CitasDashboardComponent {

}
